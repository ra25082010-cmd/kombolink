import asyncio
import json
import random
import secrets
from pathlib import Path
import html
from datetime import datetime
import logging
import aiohttp

from aiogram import Bot, Dispatcher, types, F
from aiogram.enums import ParseMode
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.filters import CommandStart
from aiogram.client.default import DefaultBotProperties
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram import F, types, Router

# --- CONFIG: замените на свои значения ---
TOKEN = "8296271696:AAFwOlghNmGi8SES19Scb7eSf6CugGEeWzY"
API_KEY = "8c7eb3898bf8f9e1c588930889d0890f63c2bcf44e76678cd251ef4d23ce968d"
BOT_USERNAME = "zarabotockkluch_bot"
IMAGE_PATH = "image.jpg"
LINKS_FILE = Path("links.json")
USERS_FILE = Path("users.json")
WITHDRAWALS_FILE = Path("withdrawals.json")
TOPUP_LOG = Path("topup_log.json")
URL = "https://api.subgram.org/get-sponsors"
BLOCKING_SUBGRAM_STATUSES = ["warning", "gender", "age", "register"]

# --- Логирование ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- SubGram helper ---
async def get_subgram_sponsors(user_id: int, chat_id: int, **kwargs) -> dict | None:
    """Универсальная функция для запроса спонсоров SubGram."""
    headers = {"Auth": API_KEY}
    payload = {"user_id": user_id, "chat_id": chat_id}
    payload.update(kwargs)

    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(URL, headers=headers, json=payload, timeout=10) as response:
                return await response.json()
        except Exception as e:
            logging.error(f"Ошибка запроса к SubGram API: {e}")
            return None

# --- Router / Dispatcher / Bot ---
bot = Bot(token=TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

# --- ADMIN ID ---
ADMIN_ID = 8263761630

# --- FSM ---
class LinkCreation(StatesGroup):
    waiting_for_name = State()
    waiting_for_url = State()
    confirming = State()

class BroadcastStates(StatesGroup):
    waiting_for_content = State()
    waiting_for_button_choice = State()
    waiting_for_button_text = State()
    waiting_for_button_url = State()
    confirming_broadcast = State()

class TopUpStates(StatesGroup):
    waiting_for_identifier = State()
    waiting_for_amount = State()
    waiting_for_mode = State()
    confirming_topup = State()

class WithdrawStates(StatesGroup):
    waiting_for_amount = State()
    waiting_for_username = State()

class AdminReplyStates(StatesGroup):
    waiting_for_reply_text = State()

# --- JSON HELPERS ---
def load_json_file(path: Path, default):
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            logger.exception("Ошибка чтения %s: %s", path, e)
            return default
    return default

def save_json_file(path: Path, data):
    try:
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        logger.exception("Ошибка записи %s: %s", path, e)

def load_links() -> list:
    return load_json_file(LINKS_FILE, [])

def save_links(links: list) -> None:
    save_json_file(LINKS_FILE, links)

def load_users() -> dict:
    return load_json_file(USERS_FILE, {})

def save_users(users: dict) -> None:
    save_json_file(USERS_FILE, users)

def load_withdrawals() -> list:
    return load_json_file(WITHDRAWALS_FILE, [])

def save_withdrawals(items: list) -> None:
    save_json_file(WITHDRAWALS_FILE, items)

def load_topup_log() -> list:
    return load_json_file(TOPUP_LOG, [])

def save_topup_log(log: list) -> None:
    save_json_file(TOPUP_LOG, log)

# --- USERS / BALANCE HELPERS ---
def ensure_user_record(user_id: int, username: str | None = None) -> None:
    users = load_users()
    uid = str(user_id)
    if uid not in users:
        users[uid] = {"balance": 0, "username": username or ""}
    else:
        if username:
            users[uid]["username"] = username
    save_users(users)

def get_user_balance(user_id: int) -> int:
    users = load_users()
    return users.get(str(user_id), {}).get("balance", 0)

def set_user_balance(user_id: int, amount: int) -> None:
    users = load_users()
    uid = str(user_id)
    if uid not in users:
        users[uid] = {"balance": int(amount), "username": ""}
    else:
        users[uid]["balance"] = int(amount)
    save_users(users)

def add_user_balance(user_id: int, amount: int) -> None:
    users = load_users()
    uid = str(user_id)
    if uid not in users:
        users[uid] = {"balance": int(amount), "username": ""}
    else:
        users[uid]["balance"] = users[uid].get("balance", 0) + int(amount)
    save_users(users)

def find_user_by_username(username: str) -> int | None:
    if username.startswith("@"):
        username = username[1:]
    users = load_users()
    for uid, info in users.items():
        if info.get("username", "").lower() == username.lower():
            try:
                return int(uid)
            except Exception:
                continue
    return None

def get_user_stats(user_id: int) -> tuple:
    links = load_links()
    total_links = sum(1 for l in links if l.get("owner_id") == user_id)
    total_clicks = sum(l.get("clicks", 0) for l in links if l.get("owner_id") == user_id)
    return total_links, total_clicks

# --- TOKEN / REF HELPERS ---
def make_random_token(length_bytes: int = 6) -> str:
    return secrets.token_urlsafe(length_bytes)

def make_unique_token() -> str:
    links = load_links()
    existing = {l.get("token") for l in links}
    for _ in range(50):
        t = make_random_token(6)
        if t not in existing:
            return t
    return secrets.token_hex(6)

def make_ref_link(token: str) -> str:
    return f"https://t.me/{BOT_USERNAME}?start={token}"

# --- KEYBOARDS ---
def main_menu(user_id: int | None = None):
    rows = [
        [
            InlineKeyboardButton(text="📋 Мои ссылки", callback_data="my_links"),
            InlineKeyboardButton(text="➕ Создать ссылку", callback_data="create_link"),
        ],
        [
            InlineKeyboardButton(text="👤 Мой профиль", callback_data="my_profile"),
        ],
    ]
    if user_id == ADMIN_ID:
        rows.append([InlineKeyboardButton(text="🛠️ Админ панель", callback_data="admin_panel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def cancel_kb():
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ Отмена", callback_data="cancel")]])

def confirm_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📝 Создать", callback_data="confirm_link"),
            InlineKeyboardButton(text="❌ Отмена", callback_data="cancel"),
        ]
    ])

def profile_menu():
    rows = [
        [InlineKeyboardButton(text="💸 Вывести баланс", callback_data="withdraw")],
        [InlineKeyboardButton(text="← Назад", callback_data="back_to_main")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)

def back_to_profile_kb():
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="← Назад", callback_data="back_to_profile")]])

def admin_panel_kb():
    rows = [
        [InlineKeyboardButton(text="📣 Рассылка", callback_data="admin_broadcast")],
        [InlineKeyboardButton(text="💳 Изменить баланс", callback_data="admin_topup")],
        [InlineKeyboardButton(text="💸 Выплаты", callback_data="admin_withdrawals")],
        [InlineKeyboardButton(text="← Назад", callback_data="admin_back")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)

def add_button_choice_kb():
    rows = [
        [InlineKeyboardButton(text="Да, добавить кнопку", callback_data="broadcast_add_button")],
        [InlineKeyboardButton(text="Нет, без кнопки", callback_data="broadcast_no_button")],
        [InlineKeyboardButton(text="Отмена", callback_data="cancel_broadcast")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)

def confirm_broadcast_kb():
    rows = [
        [InlineKeyboardButton(text="✅ Отправить рассылку", callback_data="broadcast_send")],
        [InlineKeyboardButton(text="❌ Отмена", callback_data="cancel_broadcast")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)

def confirm_topup_kb():
    rows = [
        [InlineKeyboardButton(text="✅ Подтвердить", callback_data="confirm_topup")],
        [InlineKeyboardButton(text="❌ Отмена", callback_data="cancel_topup")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)

def topup_mode_kb():
    rows = [
        [InlineKeyboardButton(text="➕ Добавить (add)", callback_data="topup_mode_add")],
        [InlineKeyboardButton(text="🔁 Установить (set)", callback_data="topup_mode_set")],
        [InlineKeyboardButton(text="Отмена", callback_data="cancel_topup")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)

def withdrawals_list_kb():
    items = load_withdrawals()
    rows = []
    for w in items:
        rows.append([InlineKeyboardButton(text=f"#{w['id']} {w.get('username','')} {w['amount']}₽", callback_data=f"payout:{w['id']}")])
    rows.append([InlineKeyboardButton(text="← Назад", callback_data="admin_panel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def payout_detail_kb(withdrawal_id: str):
    rows = [
        [InlineKeyboardButton(text="✅ Закрыть (выплата успешна)", callback_data=f"payout_close:{withdrawal_id}")],
        [InlineKeyboardButton(text="✉️ Ответить", callback_data=f"payout_reply:{withdrawal_id}")],
        [InlineKeyboardButton(text="← Назад", callback_data="admin_withdrawals")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)

# --- TEXT HELPERS ---
def profile_text_for_user(user_id: int) -> str:
    ensure_user_record(user_id)
    balance = get_user_balance(user_id)
    total_links, total_clicks = get_user_stats(user_id)
    return (
        f"👤 <b>Ваш профиль</b>\n\n"
        f"💰 Баланс: <b>{balance} ₽</b>\n"
        f"📎 Всего ссылок: <b>{total_links}</b>\n"
        f"👥 Всего переходов по вашим ссылкам: <b>{total_clicks}</b>\n\n"
    )

def ask_name_text():
    return (
        "🏷️ <b>Введите название ссылки (до 64 символов)</b>\n"
    )

def ask_url_text():
    return (
        "🔗 <b>Введите ссылку, которую нужно сократить</b>\n"
    )

def confirmation_text(name: str, url: str, ref_link: str):
    safe_name = html.escape(name)
    safe_url = html.escape(url)
    safe_ref = html.escape(ref_link)
    anchor = f'<a href="{safe_url}">{safe_name}</a>'
    return (
        "✅ <b>Подтверждение</b>\n\n"
        f"🏷️ Название: <b>{safe_name}</b>\n"
        f"🧩 Основная ссылка: {anchor}\n\n"
        f"🔗 Сокращенная ссылка:\n<code>{safe_ref}</code>\n\n"
    )

# --- PROMO ---
PROMO_LINE_1 = (
    "🚀 <b>Зарабатывайте вместе с нами:</b>\n"
    "— сокращайте ссылки в Telegram\n"
    "— получайте прибыль автоматически"
)
PROMO_LINE_2 = "📲 Чтобы начать, введите команду /start"

# -----------------------
# HANDLERS
# -----------------------

@dp.message(CommandStart())
async def on_start(message: types.Message):
    try:
        username = message.from_user.username or ""
        ensure_user_record(message.from_user.id, username)

        payload = None
        if message.text:
            parts = message.text.split(maxsplit=1)
            if len(parts) == 2:
                payload = parts[1].strip()

        # Если пришёл payload (реф токен) — ищем ссылку
        if payload:
            links = load_links()
            found = next((l for l in links if l.get("token") == payload), None)
            if found:
                opener_id = message.from_user.id
                owner_id = found.get("owner_id")

                # Сначала проверяем SubGram API — нужно ли требовать подписку
                subgram_resp = await get_subgram_sponsors(user_id=opener_id, chat_id=message.chat.id, token=payload)
                status = None
                if subgram_resp:
                    status = subgram_resp.get("status")

                # Если API вернул блокирующий статус — просим подписаться и даём кнопку проверки
                if status and status in BLOCKING_SUBGRAM_STATUSES:
                    kb = InlineKeyboardMarkup(inline_keyboard=[
                        [InlineKeyboardButton(text="✅ Проверить подписку и получить ссылку", callback_data=f"subgram-op:{payload}")],
                    ])
                    await message.answer(
                        "🔒 Для получения сокращённой ссылки необходимо подписаться на спонсоров SubGram. После подписки нажмите кнопку ниже, чтобы проверить доступ.",
                        reply_markup=kb
                    )
                    return

                # Если API недоступен или вернул ошибку — по умолчанию выдаём ссылку (чтобы не терять пользователя)
                # Если всё ок — выдаём ссылку и начисляем вознаграждение владельцу (если это не сам владелец)
                found["clicks"] = found.get("clicks", 0) + 1

                if owner_id and opener_id != owner_id:
                    reward = random.randint(1, 7)
                    add_user_balance(owner_id, reward)
                    found["earned"] = found.get("earned", 0) + reward

                save_links(links)

                safe_name = html.escape(found.get("name", "Ссылка"))
                safe_url = html.escape(found.get("url", ""))
                anchor = f'<a href="{safe_url}">{safe_name}</a>'
                await message.answer(f"🔗 <b>Сокращённая ссылка</b>\n\n{anchor}", parse_mode=ParseMode.HTML)
                await message.answer(PROMO_LINE_1, parse_mode=ParseMode.HTML)
                await message.answer(PROMO_LINE_2)
                return

        # Обычное приветствие (без payload)
        photo = FSInputFile(IMAGE_PATH)
        caption = (
            "👋 <b>Добро пожаловать в KomboLink</b>\n\n"
            "🚀 Сокращайте ссылки и получайте доход.\n\n"
            "📰 Новости: @thekomboscript\n"
            "🆘 Поддержка (за выводом также можно писать туда): @NRomaE"
        )
        await message.answer_photo(photo=photo, caption=caption, reply_markup=main_menu(message.from_user.id))
    except Exception as e:
        logger.exception("Ошибка в on_start: %s", e)
        await message.answer("Произошла ошибка при обработке /start.")

# --- PROFILE / WITHDRAW FLOW ---
@dp.callback_query(F.data == "my_profile")
async def show_profile(callback: types.CallbackQuery):
    try:
        user_id = callback.from_user.id
        await callback.message.delete()
        await callback.message.answer(profile_text_for_user(user_id), reply_markup=profile_menu())
    except Exception as e:
        logger.exception("Ошибка в show_profile: %s", e)
        await callback.message.answer("Ошибка при показе профиля.")
    finally:
        await callback.answer()

@dp.callback_query(F.data == "withdraw")
async def ask_withdraw(callback: types.CallbackQuery, state: FSMContext):
    try:
        await callback.message.delete()
        await callback.message.answer("💵 Введите сумму для вывода:", reply_markup=back_to_profile_kb())
        await state.set_state(WithdrawStates.waiting_for_amount)
    except Exception as e:
        logger.exception("Ошибка в ask_withdraw: %s", e)
        await callback.message.answer("Ошибка при запросе суммы. Попробуйте ещё раз.")
    finally:
        await callback.answer()

@dp.message(WithdrawStates.waiting_for_amount)
async def handle_withdraw_amount(message: types.Message, state: FSMContext):
    try:
        text = (message.text or "").strip()
        if not text.lstrip("-").isdigit():
            await message.answer("Неверный формат суммы. Введите целое число", reply_markup=back_to_profile_kb())
            return
        amount = int(text)
        if amount <= 0:
            await message.answer("Сумма должна быть положительной.", reply_markup=back_to_profile_kb())
            return

        # Enforce minimum 500₽
        if amount < 500:
            await message.answer("Минимальная сумма для вывода 500₽.", reply_markup=back_to_profile_kb())
            await state.clear()
            return

        user_id = message.from_user.id
        balance = get_user_balance(user_id)
        if amount > balance:
            await message.answer("❎ У вас недостаточно средств на балансе.", reply_markup=back_to_profile_kb())
            await state.clear()
            return

        await state.update_data(withdraw_amount=amount)
        await message.delete()
        await message.answer("Введите ваш юзернейм в Telegram. Важно: не меняйте ваш юзернейм пока не получите деньги", reply_markup=back_to_profile_kb())
        await state.set_state(WithdrawStates.waiting_for_username)
    except Exception as e:
        logger.exception("Ошибка в handle_withdraw_amount: %s", e)
        await message.answer("Ошибка при обработке суммы.")

@dp.message(WithdrawStates.waiting_for_username)
async def handle_withdraw_username(message: types.Message, state: FSMContext):
    try:
        username = (message.text or "").strip()
        if not username:
            await message.answer("Юзернейм не может быть пустым. Введите ваш @username .", reply_markup=back_to_profile_kb())
            return
        if not username.startswith("@"):
            username = "@" + username

        data = await state.get_data()
        amount = data.get("withdraw_amount")
        user_id = message.from_user.id

        wid = secrets.token_hex(4)
        created = datetime.now().isoformat()
        withdrawal = {
            "id": wid,
            "user_id": user_id,
            "username": username,
            "amount": int(amount),
            "created": created
        }
        items = load_withdrawals()
        items.append(withdrawal)
        save_withdrawals(items)

        # списываем баланс сразу
        add_user_balance(user_id, -int(amount))

        await message.delete()
        await message.answer(f"✅ Заявка создана: #{wid}\nСумма: {amount} ₽\nЮзернейм: {username}", reply_markup=main_menu(message.from_user.id))
        await state.clear()
    except Exception as e:
        logger.exception("Ошибка в handle_withdraw_username: %s", e)
        await message.answer("Ошибка при создании заявки.")
        await state.clear()

# --- ADMIN PANEL & WITHDRAWALS ---
@dp.callback_query(F.data == "admin_panel")
async def admin_panel(callback: types.CallbackQuery):
    try:
        if callback.from_user.id != ADMIN_ID:
            await callback.answer("Доступ запрещён.", show_alert=True)
            return
        await callback.message.delete()
        await callback.message.answer("🛠️ <b>Админ панель</b>", reply_markup=admin_panel_kb())
    except Exception as e:
        logger.exception("Ошибка в admin_panel: %s", e)
        await callback.message.answer("Ошибка в админ панели.")
    finally:
        await callback.answer()

@dp.callback_query(F.data == "admin_back")
async def admin_back(callback: types.CallbackQuery):
    try:
        if callback.from_user.id != ADMIN_ID:
            await callback.answer("Доступ запрещён.", show_alert=True)
            return
        await callback.message.delete()
        photo = FSInputFile(IMAGE_PATH)
        await callback.message.answer_photo(photo, caption="👋 <b>Добро пожаловать в HelLink</b>", reply_markup=main_menu(callback.from_user.id))
    except Exception as e:
        logger.exception("Ошибка в admin_back: %s", e)
        await callback.message.answer("Ошибка.")
    finally:
        await callback.answer()

@dp.callback_query(F.data == "admin_withdrawals")
async def admin_withdrawals(callback: types.CallbackQuery):
    try:
        if callback.from_user.id != ADMIN_ID:
            await callback.answer("Доступ запрещён.", show_alert=True)
            return
        await callback.message.delete()
        items = load_withdrawals()
        if not items:
            await callback.message.answer("📭 Заявок на выплату пока нет.", reply_markup=admin_panel_kb())
            await callback.answer()
            return
        kb = withdrawals_list_kb()
        await callback.message.answer("📭 Список заявок на выплату:", reply_markup=kb)
    except Exception as e:
        logger.exception("Ошибка в admin_withdrawals: %s", e)
        await callback.message.answer("Ошибка при показе заявок.")
    finally:
        await callback.answer()

@dp.callback_query(F.data.startswith("payout:"))
async def payout_detail(callback: types.CallbackQuery):
    try:
        if callback.from_user.id != ADMIN_ID:
            await callback.answer("Доступ запрещён.", show_alert=True)
            return
        wid = callback.data.split(":",1)[1]
        items = load_withdrawals()
        w = next((x for x in items if x["id"] == wid), None)
        if not w:
            await callback.answer("Заявка не найдена.", show_alert=True)
            return
        text = (
            f"<b>Заявка #{w['id']}</b>\n\n"
            f"• Пользователь ID: <code>{w['user_id']}</code>\n"
            f"• Юзернейм: {html.escape(w.get('username',''))}\n"
            f"• Сумма: <b>{w['amount']} ₽</b>\n"
            f"• Создана: {w['created']}\n"
        )
        await callback.message.delete()
        await callback.message.answer(text, parse_mode=ParseMode.HTML, reply_markup=payout_detail_kb(wid))
    except Exception as e:
        logger.exception("Ошибка в payout_detail: %s", e)
        await callback.answer("Ошибка при показе заявки.")
    finally:
        await callback.answer()

@dp.callback_query(F.data.startswith("payout_close:"))
async def payout_close(callback: types.CallbackQuery):
    try:
        if callback.from_user.id != ADMIN_ID:
            await callback.answer("Доступ запрещён.", show_alert=True)
            return
        wid = callback.data.split(":",1)[1]
        items = load_withdrawals()
        w = next((x for x in items if x["id"] == wid), None)
        if not w:
            await callback.answer("Заявка не найдена.", show_alert=True)
            return

        items = [x for x in items if x["id"] != wid]
        save_withdrawals(items)

        await callback.message.delete()
        await callback.message.answer(f"✅ Заявка #{wid} закрыта (выплата успешна).", reply_markup=admin_panel_kb())
        try:
            await bot.send_message(w["user_id"], f"✅ Ваша заявка #{wid} на сумму {w['amount']} ₽ отмечена как выполненная. Спасибо.")
        except Exception:
            logger.exception("Не удалось уведомить пользователя о закрытии заявки.")
    except Exception as e:
        logger.exception("Ошибка в payout_close: %s", e)
        await callback.answer("Ошибка при закрытии заявки.")
    finally:
        await callback.answer()

@dp.callback_query(F.data.startswith("payout_reply:"))
async def payout_reply(callback: types.CallbackQuery, state: FSMContext):
    try:
        if callback.from_user.id != ADMIN_ID:
            await callback.answer("Доступ запрещён.", show_alert=True)
            return
        wid = callback.data.split(":",1)[1]
        items = load_withdrawals()
        w = next((x for x in items if x["id"] == wid), None)
        if not w:
            await callback.answer("Заявка не найдена.", show_alert=True)
            return

        await state.update_data(reply_target_id=w["user_id"], reply_wid=wid)
        await callback.message.delete()
        await callback.message.answer(f"✉️ Введите сообщение, которое будет отправлено пользователю {w.get('username','')}:")
        await state.set_state(AdminReplyStates.waiting_for_reply_text)
    except Exception as e:
        logger.exception("Ошибка в payout_reply: %s", e)
        await callback.answer("Ошибка при подготовке ответа.")
    finally:
        await callback.answer()

@dp.message(AdminReplyStates.waiting_for_reply_text)
async def admin_send_reply(message: types.Message, state: FSMContext):
    try:
        if message.from_user.id != ADMIN_ID:
            await message.answer("Доступ запрещён.")
            await state.clear()
            return
        data = await state.get_data()
        target = data.get("reply_target_id")
        wid = data.get("reply_wid")
        text = message.text or ""
        try:
            await bot.send_message(target, f"✉️ Ответ по заявке #{wid}:\n\n{text}")
        except Exception:
            logger.exception("Не удалось отправить ответ пользователю.")
        await message.answer("Сообщение отправлено.", reply_markup=admin_panel_kb())
        await state.clear()
    except Exception as e:
        logger.exception("Ошибка в admin_send_reply: %s", e)
        await message.answer("Ошибка при отправке сообщения.")
        await state.clear()

# --- CREATE LINK FLOW ---
@dp.callback_query(F.data == "create_link")
async def start_create_link(callback: types.CallbackQuery, state: FSMContext):
    try:
        await callback.message.delete()
        await callback.message.answer(ask_name_text(), reply_markup=cancel_kb())
        await state.set_state(LinkCreation.waiting_for_name)
    except Exception as e:
        logger.exception("Ошибка в start_create_link: %s", e)
        await callback.message.answer("Ошибка при создании ссылки.")
    finally:
        await callback.answer()

@dp.message(LinkCreation.waiting_for_name)
async def receive_link_name(message: types.Message, state: FSMContext):
    try:
        text = (message.text or "").strip()
        if not text:
            await message.answer("Название не может быть пустым.", reply_markup=cancel_kb())
            return
        if len(text) > 64:
            await message.answer("Название слишком длинное (макс 64 символа).", reply_markup=cancel_kb())
            return
        await state.update_data(link_name=text)
        await message.delete()
        await message.answer(ask_url_text(), reply_markup=cancel_kb())
        await state.set_state(LinkCreation.waiting_for_url)
    except Exception as e:
        logger.exception("Ошибка в receive_link_name: %s", e)
        await message.answer("Ошибка при вводе названия.")

@dp.message(LinkCreation.waiting_for_url)
async def receive_link_url(message: types.Message, state: FSMContext):
    try:
        url = (message.text or "").strip()
        if not url:
            await message.answer("Ссылка не может быть пустой.", reply_markup=cancel_kb())
            return
        data = await state.get_data()
        name = data.get("link_name")
        token = make_unique_token()
        ref_link = make_ref_link(token)

        # Сохраняем ссылку
        links = load_links()
        link_obj = {
            "token": token,
            "name": name,
            "url": url,
            "owner_id": message.from_user.id,
            "clicks": 0,
            "earned": 0,
            "created": datetime.now().isoformat()
        }
        links.append(link_obj)
        save_links(links)

        await message.delete()
        await message.answer(confirmation_text(name, url, ref_link), reply_markup=main_menu(message.from_user.id), parse_mode=ParseMode.HTML)
        await state.clear()
    except Exception as e:
        logger.exception("Ошибка в receive_link_url: %s", e)
        await message.answer("Ошибка при сохранении ссылки.")
        await state.clear()

@dp.callback_query(F.data == "my_links")
async def my_links(callback: types.CallbackQuery):
    try:
        user_id = callback.from_user.id
        links = load_links()
        user_links = [l for l in links if l.get("owner_id") == user_id]
        if not user_links:
            await callback.message.delete()
            await callback.message.answer("У вас пока нет созданных ссылок.", reply_markup=main_menu(user_id))
            await callback.answer()
            return

        text_lines = []
        for l in user_links:
            token = l.get("token")
            name = html.escape(l.get("name", ""))
            clicks = l.get("clicks", 0)
            earned = l.get("earned", 0)
            ref = make_ref_link(token)
            text_lines.append(f"• <b>{name}</b>\n  🔗 <code>{ref}</code>\n  👣 Переходов: {clicks} | 💵 Заработано: {earned} ₽\n")

        await callback.message.delete()
        await callback.message.answer("\n".join(text_lines), parse_mode=ParseMode.HTML, reply_markup=main_menu(user_id))
    except Exception as e:
        logger.exception("Ошибка в my_links: %s", e)
        await callback.message.answer("Ошибка при показе ссылок.")
    finally:
        await callback.answer()

# --- SubGram callback: проверка подписки и выдача ссылки ---
@dp.callback_query(F.data.startswith("subgram-op:"))
async def handle_subgram_op(callback: types.CallbackQuery):
    try:
        # callback.data формат: subgram-op:<token>
        token = callback.data.split(":", 1)[1]
        opener_id = callback.from_user.id
        chat_id = callback.message.chat.id

        # Повторный запрос в SubGram API
        resp = await get_subgram_sponsors(user_id=opener_id, chat_id=chat_id, token=token)
        status = None
        if resp:
            status = resp.get("status")

        # Если всё ещё блокирующий статус — уведомляем пользователя
        if status and status in BLOCKING_SUBGRAM_STATUSES:
            await callback.answer("Доступ пока закрыт. Пожалуйста, подпишитесь на спонсоров и повторите проверку.", show_alert=True)
            return

        # На случай ошибки API — разрешаем доступ (как в примере)
        # На случай успеха — выдаём ссылку
        links = load_links()
        found = next((l for l in links if l.get("token") == token), None)
        if not found:
            await callback.answer("Ссылка не найдена.", show_alert=True)
            return

        opener_id = callback.from_user.id
        owner_id = found.get("owner_id")

        # Увеличиваем счётчик и начисляем вознаграждение владельцу (если это не сам владелец)
        found["clicks"] = found.get("clicks", 0) + 1

        if owner_id and opener_id != owner_id:
            reward = random.randint(1, 7)
            add_user_balance(owner_id, reward)
            found["earned"] = found.get("earned", 0) + reward

        save_links(links)

        safe_name = html.escape(found.get("name", "Ссылка"))
        safe_url = html.escape(found.get("url", ""))
        anchor = f'<a href="{safe_url}">{safe_name}</a>'
        # удаляем сообщение с кнопкой и отправляем ссылку
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(f"🔗 <b>Сокращённая ссылка</b>\n\n{anchor}", parse_mode=ParseMode.HTML)
        await callback.message.answer(PROMO_LINE_1, parse_mode=ParseMode.HTML)
        await callback.message.answer(PROMO_LINE_2)
    except Exception as e:
        logger.exception("Ошибка в handle_subgram_op: %s", e)
        await callback.answer("Произошла ошибка при проверке подписки.", show_alert=True)
    finally:
        try:
            await callback.answer()
        except Exception:
            pass

# --- Cancel / Back handlers (простые реализации) ---
@dp.callback_query(F.data == "cancel")
async def handle_cancel(callback: types.CallbackQuery, state: FSMContext):
    try:
        await state.clear()
        await callback.message.delete()
        await callback.message.answer("Отменено.", reply_markup=main_menu(callback.from_user.id))
    except Exception:
        pass
    finally:
        await callback.answer()

@dp.callback_query(F.data == "back_to_profile")
async def back_to_profile(callback: types.CallbackQuery):
    try:
        await callback.message.delete()
        await callback.message.answer(profile_text_for_user(callback.from_user.id), reply_markup=profile_menu())
    except Exception:
        pass
    finally:
        await callback.answer()

@dp.callback_query(F.data == "back_to_main")
async def back_to_main(callback: types.CallbackQuery):
    try:
        await callback.message.delete()
        await callback.message.answer("Главное меню", reply_markup=main_menu(callback.from_user.id))
    except Exception:
        pass
    finally:
        await callback.answer()

# --- Запуск бота (замените старый блок с executor) ---
async def main():
    try:
        logger.info("Bot started")
        await dp.start_polling(bot, skip_updates=True)
    except Exception as e:
        logger.exception("Ошибка при запуске бота: %s", e)
    finally:
        try:
            # корректно закрываем сессию aiohttp внутри Bot
            await bot.session.close()
        except Exception:
            pass

if __name__ == "__main__":
    asyncio.run(main())

